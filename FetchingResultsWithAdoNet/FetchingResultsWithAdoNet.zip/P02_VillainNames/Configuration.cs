﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_VillainNames
{
    public static class Configuration
    {
        public static readonly string ConnectionString = @"Server=(localdb)\MSSQLLocalDB; DATABASE=MinionsDB; Integrated Security=True";
    }
}
