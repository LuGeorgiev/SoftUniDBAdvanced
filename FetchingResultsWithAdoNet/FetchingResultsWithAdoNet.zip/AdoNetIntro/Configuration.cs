﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdoNetIntro
{
    public static class Configuration
    {
        public static readonly string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Integrated Security=True";
    }
}
